Tato slozka obsahuje lokalni zalohy vytvorene Setupem pro bezpecne vraceni
adapteru a VB-CABLE. Soubory *.json jsou specificke pro jeden pocitac a nemaji
se commitovat ani pridavat do verejneho GitHub Release ZIPu.
