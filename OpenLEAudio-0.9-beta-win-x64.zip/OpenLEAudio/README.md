# OpenLEAudio 0.9 Beta — Windows x64

Tato složka je hotový uživatelský balíček. Neobsahuje zdrojové kódy,
testy, zachycené pakety ani vývojové nástroje.

## Spuštění

Spusťte **APLIKACE - spustit.bat**. Launcher nejdřív ověří:

- Microsoft .NET 8 Desktop Runtime x64
- Microsoft Windows App Runtime 1.8 x64

Pokud něco chybí, nabídne automatické stažení oficiálních instalátorů
Microsoftu. Stažené soubory uloží do `dependencies`, takže je lze znovu
použít nebo přibalit do offline ZIPu.

## První nastavení

V aplikaci otevřete **Příprava / Setup** a postupujte v tomto pořadí:

1. Podepsat driver (podpis se obnovuje každé dva roky).
2. Nainstalovat a nastavit VB-CABLE.
3. Vybrat Bluetooth adaptér a přepnout jej na OpenLEAudio/WinUSB stack.
4. Aplikaci úplně ukončit přes ikonu vedle hodin a znovu spustit.

Detekce adaptéru používá Hardware ID uvedené v podepsaném INF, proto
funguje před přepnutím i poté, co je zařízení vedené jako WinUSB/USBDevice.

## Bezpečný návrat

Kdyby vlastní stack nefungoval, spusťte **ADAPTER - VRATIT Windows.bat**.
Původní stav adaptéru a VB-CABLE se ukládá do `runtime-data`.

## Obsah balíčku

- `OpenLEAudio/` — aplikace a audio jádro
- `driver/` — podepisovaný WinUSB INF a katalog
- `scripts/` — pouze tři skripty používané obrazovkou Setup
- `dependencies/` — volitelná cache Microsoft runtime instalátorů
- `runtime-data/` — zálohy pro bezpečné obnovení

Pro GitHub nahrajte ZIP vytvořený ze složky `release` jako Release asset.
Uživatelé potom nemusí stahovat složku `dev`.
