@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "OUT=OpenLEAudio"

set "MISSING=0"
where dotnet.exe >nul 2>nul
if errorlevel 1 (
    set "MISSING=1"
) else (
    dotnet --list-runtimes 2>nul | findstr /B /C:"Microsoft.WindowsDesktop.App 8." >nul
    if errorlevel 1 set "MISSING=1"
)

powershell.exe -NoProfile -NonInteractive -Command ^
  "if (Get-AppxPackage -Name 'Microsoft.WindowsAppRuntime.1.8*' -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }"
if errorlevel 1 set "MISSING=1"

if "%MISSING%"=="1" (
    echo.
    echo OpenLEAudio potrebuje Microsoft .NET 8 Desktop Runtime a Windows App Runtime 1.8.
    echo Nektera zavislost chybi. Lze ji automaticky stahnout z oficialniho webu Microsoftu.
    echo.
    choice /M "Stahnout a nainstalovat zavislosti"
    if errorlevel 2 exit /b 1
    call "%~dp0INSTALOVAT ZAVISLOSTI.bat"
    if errorlevel 1 exit /b 1
)

if not exist "%OUT%\OpenLEAudio.exe" (
    echo Aplikace neni v adresari OpenLEAudio. Obnov pripraveny balicek ze slozky dev.
    pause
    exit /b 1
)
start "" "%OUT%\OpenLEAudio.exe"
