@echo off
title OpenLEAudio - vratit Windows driver
REM Vyzada prava spravce a vrati adapter zpet pod Windows.
REM Tohle je zachranna brzda - spust kdykoli, kdyz se neco pokazi.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-NoExit','-File','\"%~dp0scripts\adapter-driver.ps1\"','-Restore'"
