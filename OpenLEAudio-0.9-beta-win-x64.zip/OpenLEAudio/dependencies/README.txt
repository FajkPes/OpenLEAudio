OpenLEAudio dependencies cache
==============================

Tato slozka muze zustat prazdna. Launcher chybejici zavislosti rozpozna a
INSTALOVAT ZAVISLOSTI.bat sem stahne oficialni instalatory Microsoftu:

- windowsdesktop-runtime-8-x64.exe
- windows-app-runtime-1.8-x64.exe

Pro offline kompletni balicek sem lze oba instalatory vlozit pred zabalenim ZIPu.
Instalacni BAT je pak pouzije bez stahovani. Tyto EXE nejsou pro bezny maly
GitHub Release potreba a zamerne nejsou soucasti zakladniho balicku.
